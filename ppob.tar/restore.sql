--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_tarif DROP CONSTRAINT tb_tarif_pkey;
ALTER TABLE ONLY public.tb_tagihan DROP CONSTRAINT tb_tagihan_pkey;
ALTER TABLE ONLY public.tb_penggunaan DROP CONSTRAINT tb_penggunaan_pkey;
ALTER TABLE ONLY public.tb_pembayaran DROP CONSTRAINT tb_pembayaran_pkey;
ALTER TABLE ONLY public.tb_pelanggan DROP CONSTRAINT tb_pelanggan_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_admin DROP CONSTRAINT tb_admin_pkey;
DROP TABLE public.tb_tarif;
DROP TABLE public.tb_tagihan;
DROP TABLE public.tb_penggunaan;
DROP TABLE public.tb_pembayaran;
DROP TABLE public.tb_pelanggan;
DROP TABLE public.tb_level;
DROP TABLE public.tb_admin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin integer NOT NULL,
    username character varying(100),
    password character varying(100),
    nama_admin character varying(100),
    id_level integer
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying(100)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pelanggan (
    id_pelanggan character varying(12) NOT NULL,
    username character varying(100),
    password character varying(100),
    nomor_kwh integer,
    nama_pelanggan character varying(100),
    alamat character varying(100),
    id_tarif integer
);


ALTER TABLE tb_pelanggan OWNER TO postgres;

--
-- Name: tb_pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pembayaran (
    id_pembayaran character varying(12) NOT NULL,
    id_tagihan character varying(12),
    id_pelanggan character varying(12),
    tanggal_pembayaran date,
    bulan_bayar date,
    biaya_admin integer,
    total_biaya integer,
    id_admin integer
);


ALTER TABLE tb_pembayaran OWNER TO postgres;

--
-- Name: tb_penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penggunaan (
    id_penggunaan character varying(12) NOT NULL,
    id_pelanggan character varying(12),
    bulan date,
    tahun date,
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE tb_penggunaan OWNER TO postgres;

--
-- Name: tb_tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tagihan (
    id_tagihan character varying(12) NOT NULL,
    id_penggunaan character varying(12),
    id_pelanggan character varying(12),
    bulan date,
    tahun date,
    jumlah_meter integer,
    status character varying(50)
);


ALTER TABLE tb_tagihan OWNER TO postgres;

--
-- Name: tb_tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tarif (
    id_tarif integer NOT NULL,
    daya integer,
    tarifperkwh integer
);


ALTER TABLE tb_tarif OWNER TO postgres;

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: tb_pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY tb_pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: tb_pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_biaya, id_admin) FROM stdin;
\.
COPY tb_pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_biaya, id_admin) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tb_penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2827.dat';

--
-- Data for Name: tb_tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tb_tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: tb_tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2830.dat';

--
-- Name: tb_admin tb_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin
    ADD CONSTRAINT tb_admin_pkey PRIMARY KEY (id_admin);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pelanggan tb_pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pelanggan
    ADD CONSTRAINT tb_pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: tb_pembayaran tb_pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran
    ADD CONSTRAINT tb_pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: tb_penggunaan tb_penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penggunaan
    ADD CONSTRAINT tb_penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tb_tagihan tb_tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tagihan
    ADD CONSTRAINT tb_tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tb_tarif tb_tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tarif
    ADD CONSTRAINT tb_tarif_pkey PRIMARY KEY (id_tarif);


--
-- PostgreSQL database dump complete
--

